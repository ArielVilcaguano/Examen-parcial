package com.example.vilcaguano_ariel_examenparcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Respuesta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respuesta)

        val r: TextView = findViewById(R.id.txt_res1)


        val textView1: TextView = findViewById(R.id.txt_res1)
        val receivedMessage: String = intent.extras?.getString("EXTRA_MESSAGE").orEmpty()
        textView1.text = receivedMessage


        val btn: Button = findViewById(R.id.Btn_regresar)
        btn.setOnClickListener {
            val intent: Intent = Intent(this, Calcular::class.java)
            startActivity(intent)
        }

    }

}