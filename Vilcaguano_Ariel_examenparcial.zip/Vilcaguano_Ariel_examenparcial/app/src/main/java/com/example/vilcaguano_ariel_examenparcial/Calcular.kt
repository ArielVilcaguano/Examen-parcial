package com.example.vilcaguano_ariel_examenparcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

lateinit var n1: EditText
lateinit var n2 : EditText
lateinit var btnSumar : Button
lateinit var txtres : TextView



class Calcular : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular)
        val edittext1: TextView = findViewById(R.id.txt_res1)

        n1 = findViewById(R.id.txt_n1)
        n2 = findViewById(R.id.txt_n2)
        btnSumar = findViewById(R.id.btn_sumar)
        txtres = findViewById(R.id.txt_res1)

        btnSumar.setOnClickListener(View.OnClickListener {

            try {

                val n_1 = Integer.parseInt(n1.text.toString())
                val n_2 = Integer.parseInt(n2.text.toString())
                txtres.setText("Respuesta: " + sumar(n_1, n_2))
            } catch (ex: Exception) {
            }
            val message: String = edittext1.text.toString()
            val sendMessage = Intent(this, Respuesta::class.java)
            sendMessage.putExtra("EXTRA_MESSAGE", message)
            startActivity(sendMessage)
        })

    }

    fun sumar(numero1: Int, numero2: Int): Int {

        return numero1 + numero2


    }

}
